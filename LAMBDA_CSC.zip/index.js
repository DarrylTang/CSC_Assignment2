// dependencies
//var async = require('async');
var AWS = require('aws-sdk');
var util = require('util');

// get reference to S3 client 
var s3 = new AWS.S3();

// Set the region 
AWS.config.update({ region: 'ap-southeast-1' });

// Create the DynamoDB service object
var ddb = new AWS.DynamoDB({ apiVersion: '2012-10-08' });

// https://stackoverflow.com/questions/45448475/s3-object-metadata-lambda-function 

exports.handler = function (event, context, callback) {
   // Read options from the event.
   console.log("Reading options from event:\n", util.inspect(event, { depth: 5 }));
   var srcBucket = event.Records[0].s3.bucket.name;
   // Object key may have spaces or unicode non-ASCII characters.
   var srcKey =
      decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, " "));

   // Infer the image type.
   var typeMatch = srcKey.match(/\.([^.]*)$/);
   if (!typeMatch) {
      callback("Could not determine the image type.");
      return;
   }
   var imageType = typeMatch[1];
   if (imageType != "jpg" && imageType != "png") {
      callback('Unsupported image type: ${imageType}');
      return;
   }

   /* The following example retrieves an object metadata. */
   var params = {
      Bucket: srcBucket,
      Key: srcKey
   };
   s3.headObject(params, function (err, data) {
      if (err) {
         console.log(err, err.stack); // an error occurred
      }
      else {
         console.log(data);           // successful response

         var params = {
            TableName: 'csc_image',
            Item: {
               'userid': {"S": data.Metadata.userid},
               'image_path': {"S": srcKey},
               'timestamp': {"S": event.Records[0].eventTime },
               'description': {"S": data.Metadata.description}
            },

         };
         ddb.putItem(params, function(err, data) {
            if (err) {
              console.log("Error", err);
            } else {
              console.log("Success", data);
            }
          });
      }
      /*
   data = {
    AcceptRanges: "bytes", 
    ContentLength: 3191, 
    ContentType: "image/jpeg", 
    ETag: "\"6805f2cfc46c0f04559748bb039d69ae\"", 
    LastModified: <Date Representation>, 
    Metadata: {
    }, 
    VersionId: "null"
   }
   */
   });


};

/* SAMPLE REQUEST

{
   "Records":[
      {
         "eventVersion":"2.0",
         "eventSource":"aws:s3",
         "awsRegion":"us-west-2",
         "eventTime":"1970-01-01T00:00:00.000Z",
         "eventName":"ObjectCreated:Put",
         "userIdentity":{
            "principalId":"AIDAJDPLRKLG7UEXAMPLE"
         },
         "requestParameters":{
            "sourceIPAddress":"127.0.0.1"
         },
         "responseElements":{
            "x-amz-request-id":"C3D13FE58DE4C810",
            "x-amz-id-2":"FMyUVURIY8/IgAtTv8xRjskZQpcIZ9KG4V5Wp6S7S/JRWeUWerMUE5JgHvANOjpD"
         },
         "s3":{
            "s3SchemaVersion":"1.0",
            "configurationId":"testConfigRule",
            "bucket":{
               "name":"sourcebucket",
               "ownerIdentity":{
                  "principalId":"A3NL1KOZZKExample"
               },
               "arn":"arn:aws:s3:::sourcebucket"
            },
            "object":{
               "key":"HappyFace.jpg",
               "size":1024,
               "eTag":"d41d8cd98f00b204e9800998ecf8427e",
               "versionId":"096fKKXTRTtl3on89fVO.nfljtsv6qko"
            }
         }
      }
   ]
}

*/